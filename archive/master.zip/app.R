library(shiny)
library(rstudioapi)
# setwd('E:/teamconferenceDashboard')
# runApp(appDir = "/Volumes/NO NAME/teamConference")

appLoc <- getActiveDocumentContext()$path
setwd(dirname(appLoc))
runApp()
